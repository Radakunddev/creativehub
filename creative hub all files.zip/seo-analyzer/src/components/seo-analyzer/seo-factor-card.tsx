import React from 'react';
import { SeoFactor } from '@/types';
import { cn } from '@/lib/utils';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  CheckCircle, 
  AlertCircle, 
  XCircle, 
  HelpCircle, 
  ChevronDown, 
  ChevronUp,
  ArrowUp,
  ArrowRight,
  ArrowDown
} from 'lucide-react';

interface SeoFactorCardProps {
  factor: SeoFactor;
  expanded?: boolean;
  onToggle?: () => void;
}

const SeoFactorCard: React.FC<SeoFactorCardProps> = ({ 
  factor, 
  expanded = false,
  onToggle
}) => {
  const { 
    name, 
    status, 
    score, 
    maxScore, 
    details, 
    recommendations,
    priority
  } = factor;
  
  // 根据状态返回相应的图标和颜色
  const getStatusInfo = () => {
    switch (status) {
      case 'excellent':
        return { 
          icon: <CheckCircle className="h-5 w-5" />, 
          color: 'text-green-500 bg-green-50',
          label: '优秀'
        };
      case 'good':
        return { 
          icon: <CheckCircle className="h-5 w-5" />, 
          color: 'text-blue-500 bg-blue-50',
          label: '良好'
        };
      case 'needs-improvement':
        return { 
          icon: <AlertCircle className="h-5 w-5" />, 
          color: 'text-yellow-500 bg-yellow-50',
          label: '需改进'
        };
      case 'poor':
        return { 
          icon: <XCircle className="h-5 w-5" />, 
          color: 'text-red-500 bg-red-50',
          label: '较差'
        };
      default:
        return { 
          icon: <HelpCircle className="h-5 w-5" />, 
          color: 'text-gray-500 bg-gray-50',
          label: '未检查'
        };
    }
  };
  
  // 根据优先级返回相应的图标和标签
  const getPriorityInfo = () => {
    switch (priority) {
      case 'high':
        return { 
          icon: <ArrowUp className="h-4 w-4" />,
          color: 'bg-red-100 text-red-800',
          label: '高优先级'
        };
      case 'medium':
        return { 
          icon: <ArrowRight className="h-4 w-4" />,
          color: 'bg-yellow-100 text-yellow-800',
          label: '中优先级'
        };
      case 'low':
        return { 
          icon: <ArrowDown className="h-4 w-4" />,
          color: 'bg-green-100 text-green-800',
          label: '低优先级'
        };
    }
  };
  
  const statusInfo = getStatusInfo();
  const priorityInfo = getPriorityInfo();
  const percentage = Math.round((score / maxScore) * 100);
  
  return (
    <Card className={cn("mb-4 overflow-hidden transition-all duration-200",
      expanded ? "shadow-md" : "shadow-sm hover:shadow-md"
    )}>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-2">
            <span className={cn("rounded-full p-1", statusInfo.color)}>
              {statusInfo.icon}
            </span>
            <CardTitle className="text-lg">{name}</CardTitle>
          </div>
          
          <div className="flex items-center gap-2">
            <Badge variant="outline" className={priorityInfo.color}>
              <span className="flex items-center gap-1">
                {priorityInfo.icon}
                {priorityInfo.label}
              </span>
            </Badge>
            <span className="text-sm font-medium">
              {score}/{maxScore} ({percentage}%)
            </span>
            {onToggle && (
              <button 
                onClick={onToggle}
                className="p-1 rounded-full hover:bg-gray-100"
                aria-label={expanded ? "收起详情" : "展开详情"}
              >
                {expanded ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
              </button>
            )}
          </div>
        </div>
        <CardDescription>
          {details}
        </CardDescription>
      </CardHeader>
      
      {expanded && recommendations.length > 0 && (
        <CardContent className="pt-0">
          <div className="mt-2">
            <h4 className="font-medium text-sm mb-2">优化建议:</h4>
            <ul className="list-disc pl-5 space-y-1">
              {recommendations.map((recommendation, index) => (
                <li key={index} className="text-sm text-gray-700">
                  {recommendation}
                </li>
              ))}
            </ul>
          </div>
        </CardContent>
      )}
      
      <CardFooter className="pt-0 pb-3">
        <div className="w-full bg-gray-200 rounded-full h-1.5">
          <div 
            className={cn(
              "h-1.5 rounded-full", 
              percentage >= 80 ? "bg-green-500" : 
              percentage >= 60 ? "bg-blue-500" : 
              percentage >= 40 ? "bg-yellow-500" : 
              "bg-red-500"
            )}
            style={{ width: `${percentage}%` }}
          />
        </div>
      </CardFooter>
    </Card>
  );
};

export default SeoFactorCard;