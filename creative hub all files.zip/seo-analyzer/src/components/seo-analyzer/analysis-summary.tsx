import React from 'react';
import { AnalysisResult, CategoryResults, SeoFactor } from '@/types';
import { Card, CardContent } from '@/components/ui/card';
import SeoScoreGauge from '@/components/ui/seo-score-gauge';
import { Button } from '@/components/ui/button';
import { Download, RefreshCw } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { sortFactorsByPriority } from '@/lib/seo-rules';
import { getSeoScoreGrade } from '@/lib/seo-rules';
import { formatDate } from '@/lib/utils';
import html2pdf from 'html2pdf.js';

interface AnalysisSummaryProps {
  result: AnalysisResult;
  categoryResults: CategoryResults;
  onReanalyze?: () => void;
}

const AnalysisSummary: React.FC<AnalysisSummaryProps> = ({ 
  result,
  categoryResults,
  onReanalyze
}) => {
  const { url, totalScore, maxPossibleScore, timestamp } = result;
  const percentage = Math.round((totalScore / maxPossibleScore) * 100);
  
  // 按类别准备图表数据
  const chartData = Object.entries(categoryResults).map(([category, data]) => ({
    name: getCategoryName(category),
    percentage: Math.round(data.percentage),
    score: data.score,
    maxScore: data.maxScore,
    fill: getCategoryColor(data.percentage)
  }));
  
  // 获取最高优先级的改进建议
  const getTopRecommendations = (): SeoFactor[] => {
    // 收集所有因素
    const allFactors = Object.values(categoryResults).flatMap(c => c.factors);
    
    // 按优先级排序
    const sorted = sortFactorsByPriority(allFactors);
    
    // 只返回需要改进的高优先级项目
    return sorted
      .filter(f => f.status === 'poor' || f.status === 'needs-improvement')
      .slice(0, 3);
  };
  
  const topRecommendations = getTopRecommendations();
  
  // 导出PDF报告
  const exportPdf = () => {
    const element = document.getElementById('analysis-report');
    if (!element) return;
    
    const opt = {
      margin: 10,
      filename: `SEO_Analysis_${new Date().toISOString().split('T')[0]}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2 },
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
    };
    
    html2pdf().from(element).set(opt).save();
  };
  
  return (
    <div className="space-y-6">
      <Card className="overflow-hidden">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="flex-1">
              <h2 className="text-2xl font-bold mb-2">SEO分析结果</h2>
              <p className="text-gray-500 mb-4">
                <span className="font-medium">{url}</span>
                <br />
                分析时间: {formatDate(new Date(timestamp))}
              </p>
              
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="bg-gray-50 p-3 rounded-lg">
                  <p className="text-sm text-gray-500">总得分</p>
                  <p className="text-2xl font-bold">
                    {totalScore}/{maxPossibleScore}
                  </p>
                </div>
                <div className="bg-gray-50 p-3 rounded-lg">
                  <p className="text-sm text-gray-500">SEO评级</p>
                  <p className="text-2xl font-bold" style={{ 
                    color: percentage >= 80 ? '#22c55e' : 
                    percentage >= 60 ? '#f59e0b' : '#ef4444' 
                  }}>
                    {getSeoScoreGrade(percentage)}
                  </p>
                </div>
              </div>
              
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  onClick={onReanalyze}
                  className="flex-1"
                >
                  <RefreshCw className="mr-2 h-4 w-4" />
                  重新分析
                </Button>
                <Button 
                  onClick={exportPdf}
                  className="flex-1"
                >
                  <Download className="mr-2 h-4 w-4" />
                  导出报告
                </Button>
              </div>
            </div>
            
            <div className="flex-1 flex justify-center">
              <SeoScoreGauge 
                score={totalScore} 
                maxScore={maxPossibleScore}
                size="lg"
              />
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardContent className="p-6">
          <h3 className="text-xl font-bold mb-4">类别得分</h3>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={chartData}
                layout="vertical"
                margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
              >
                <XAxis type="number" domain={[0, 100]} />
                <YAxis dataKey="name" type="category" width={100} />
                <Tooltip
                  formatter={(value, name, props) => {
                    return [`${value}% (${props.payload.score}/${props.payload.maxScore})`, props.payload.name];
                  }}
                />
                <Bar dataKey="percentage" radius={[0, 4, 4, 0]}>
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
      
      {topRecommendations.length > 0 && (
        <Card>
          <CardContent className="p-6">
            <h3 className="text-xl font-bold mb-4">优先改进项</h3>
            <ul className="space-y-3">
              {topRecommendations.map((factor, index) => (
                <li key={factor.id} className="border-l-4 border-red-500 pl-4 py-2">
                  <h4 className="font-medium">{factor.name}</h4>
                  <p className="text-sm text-gray-600 mt-1">{factor.details}</p>
                  {factor.recommendations.length > 0 && (
                    <p className="text-sm font-medium mt-2 text-red-600">
                      建议: {factor.recommendations[0]}
                    </p>
                  )}
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}
      
      {/* 隐藏的用于导出PDF的完整报告 */}
      <div id="analysis-report" className="hidden">
        <div className="p-6">
          <h1 className="text-2xl font-bold mb-2">SEO分析报告</h1>
          <p>
            <strong>网站:</strong> {url}<br />
            <strong>分析时间:</strong> {formatDate(new Date(timestamp))}<br />
            <strong>总分:</strong> {totalScore}/{maxPossibleScore} ({percentage}%)<br />
            <strong>SEO评级:</strong> {getSeoScoreGrade(percentage)}
          </p>
          
          <h2 className="text-xl font-bold mt-6 mb-3">类别得分</h2>
          <table className="border-collapse w-full">
            <thead>
              <tr>
                <th className="border p-2 text-left">类别</th>
                <th className="border p-2 text-left">得分</th>
                <th className="border p-2 text-left">百分比</th>
              </tr>
            </thead>
            <tbody>
              {Object.entries(categoryResults).map(([category, data]) => (
                <tr key={category}>
                  <td className="border p-2">{getCategoryName(category)}</td>
                  <td className="border p-2">{data.score}/{data.maxScore}</td>
                  <td className="border p-2">{Math.round(data.percentage)}%</td>
                </tr>
              ))}
            </tbody>
          </table>
          
          <h2 className="text-xl font-bold mt-6 mb-3">详细分析结果</h2>
          {Object.entries(categoryResults).map(([category, { factors }]) => (
            <div key={category} className="mb-6">
              <h3 className="text-lg font-bold mb-2">{getCategoryName(category)}</h3>
              <table className="border-collapse w-full">
                <thead>
                  <tr>
                    <th className="border p-2 text-left">检查项</th>
                    <th className="border p-2 text-left">状态</th>
                    <th className="border p-2 text-left">详情</th>
                    <th className="border p-2 text-left">建议</th>
                  </tr>
                </thead>
                <tbody>
                  {factors.map(factor => (
                    <tr key={factor.id}>
                      <td className="border p-2">{factor.name}</td>
                      <td className="border p-2">{getStatusLabel(factor.status)}</td>
                      <td className="border p-2">{factor.details}</td>
                      <td className="border p-2">
                        {factor.recommendations.map((rec, i) => (
                          <p key={i} className="mb-1">{i + 1}. {rec}</p>
                        ))}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// 辅助函数
const getCategoryName = (category: string): string => {
  const map: Record<string, string> = {
    basic: '基础SEO要素',
    content: '内容结构分析',
    technical: '技术SEO',
    advanced: '高级SEO功能'
  };
  return map[category] || category;
};

const getCategoryColor = (percentage: number): string => {
  if (percentage >= 80) return '#22c55e'; // 绿色
  if (percentage >= 60) return '#60a5fa'; // 蓝色
  if (percentage >= 40) return '#f59e0b'; // 黄色
  return '#ef4444'; // 红色
};

const getStatusLabel = (status: string): string => {
  const map: Record<string, string> = {
    'excellent': '优秀',
    'good': '良好',
    'needs-improvement': '需改进',
    'poor': '较差',
    'not-checked': '未检查'
  };
  return map[status] || status;
};

export default AnalysisSummary;