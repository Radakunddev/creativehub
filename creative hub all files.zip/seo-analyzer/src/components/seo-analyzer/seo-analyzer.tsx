import React, { useState } from 'react';
import UrlInputForm from './url-input-form';
import ProgressIndicator from '@/components/ui/progress-indicator';
import CategoryResults from './category-results';
import AnalysisSummary from './analysis-summary';
import useSeoAnalyzer from '@/hooks/use-seo-analyzer';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

const SeoAnalyzer: React.FC = () => {
  const { 
    analyzeSeo, 
    resetAnalysis, 
    analysisResult, 
    categoryResults, 
    progress, 
    error 
  } = useSeoAnalyzer();
  
  const [activeTab, setActiveTab] = useState<string>('summary');
  
  const handleAnalyze = async (url: string) => {
    await analyzeSeo(url);
    setActiveTab('summary');
  };
  
  const handleReanalyze = () => {
    resetAnalysis();
    setActiveTab('analyze');
  };
  
  return (
    <div className="w-full max-w-7xl mx-auto">
      <Tabs 
        value={activeTab} 
        onValueChange={setActiveTab}
        className="w-full"
      >
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="analyze">分析网站</TabsTrigger>
          <TabsTrigger 
            value="summary" 
            disabled={!analysisResult}
          >
            分析结果
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="analyze" className="pt-6">
          <Card className="p-6">
            <h2 className="text-2xl font-bold mb-6">SEO网站分析</h2>
            <UrlInputForm 
              onAnalyze={handleAnalyze} 
              isLoading={progress.status === 'loading' || progress.status === 'analyzing'}
              error={error}
            />
            
            {(progress.status === 'loading' || progress.status === 'analyzing') && (
              <div className="mt-8">
                <ProgressIndicator progress={progress} />
              </div>
            )}
          </Card>
          
          {analysisResult && (
            <div className="mt-6">
              <button
                onClick={() => setActiveTab('summary')}
                className="text-primary font-medium hover:underline"
              >
                查看分析结果 →
              </button>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="summary" className="pt-6">
          {analysisResult && categoryResults && (
            <div className="space-y-6">
              <AnalysisSummary 
                result={analysisResult}
                categoryResults={categoryResults}
                onReanalyze={handleReanalyze}
              />
              
              <div>
                <h3 className="text-xl font-bold mb-4">详细分析</h3>
                <CategoryResults results={categoryResults} />
              </div>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default SeoAnalyzer;