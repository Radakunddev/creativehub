import React, { useState } from 'react';
import { CategoryResults, SeoFactor } from '@/types';
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';
import SeoFactorCard from './seo-factor-card';
import { cn } from '@/lib/utils';
import { sortFactorsByPriority } from '@/lib/seo-rules';

interface CategoryResultsProps {
  results: CategoryResults;
  defaultOpen?: string[];
}

// 类别映射
const categoryMap: Record<string, { label: string, icon: string }> = {
  basic: { 
    label: '基础SEO要素', 
    icon: '🏷️' 
  },
  content: { 
    label: '内容结构分析', 
    icon: '📝' 
  },
  technical: { 
    label: '技术SEO', 
    icon: '⚙️' 
  },
  advanced: { 
    label: '高级SEO功能', 
    icon: '🚀' 
  }
};

const CategoryResultsComponent: React.FC<CategoryResultsProps> = ({ 
  results,
  defaultOpen = ['basic']
}) => {
  const [openCategories, setOpenCategories] = useState<string[]>(defaultOpen);
  const [expandedFactors, setExpandedFactors] = useState<Record<string, boolean>>({});
  
  const toggleCategory = (category: string) => {
    setOpenCategories(prev => 
      prev.includes(category)
        ? prev.filter(c => c !== category)
        : [...prev, category]
    );
  };
  
  const toggleFactor = (factorId: string) => {
    setExpandedFactors(prev => ({
      ...prev,
      [factorId]: !prev[factorId]
    }));
  };
  
  return (
    <Accordion 
      type="multiple" 
      value={openCategories}
      className="w-full"
    >
      {Object.entries(results).map(([category, { factors, score, maxScore, percentage }]) => {
        // 对因素进行排序
        const sortedFactors = sortFactorsByPriority(factors);
        
        return (
          <AccordionItem 
            value={category} 
            key={category}
            className="border rounded-lg mb-4 overflow-hidden"
          >
            <AccordionTrigger 
              onClick={() => toggleCategory(category)}
              className={cn(
                "px-4 py-3 hover:no-underline",
                percentage >= 80 ? "bg-green-50" :
                percentage >= 60 ? "bg-blue-50" :
                percentage >= 40 ? "bg-yellow-50" :
                "bg-red-50"
              )}
            >
              <div className="flex justify-between items-center w-full">
                <div className="flex items-center gap-2 text-left">
                  <span className="text-xl">{categoryMap[category]?.icon || '📊'}</span>
                  <span className="font-medium text-lg">
                    {categoryMap[category]?.label || category}
                  </span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="flex flex-col items-end">
                    <span className="font-medium">
                      {score}/{maxScore} 分
                    </span>
                    <span className={cn(
                      "text-sm",
                      percentage >= 80 ? "text-green-600" :
                      percentage >= 60 ? "text-blue-600" :
                      percentage >= 40 ? "text-yellow-600" :
                      "text-red-600"
                    )}>
                      {percentage.toFixed(0)}%
                    </span>
                  </div>
                  <div className="w-16 h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div
                      className={cn(
                        "h-full rounded-full",
                        percentage >= 80 ? "bg-green-500" :
                        percentage >= 60 ? "bg-blue-500" :
                        percentage >= 40 ? "bg-yellow-500" :
                        "bg-red-500"
                      )}
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              </div>
            </AccordionTrigger>
            <AccordionContent className="px-4 py-3">
              <div className="space-y-4">
                {sortedFactors.map((factor: SeoFactor) => (
                  <SeoFactorCard
                    key={factor.id}
                    factor={factor}
                    expanded={!!expandedFactors[factor.id]}
                    onToggle={() => toggleFactor(factor.id)}
                  />
                ))}
              </div>
            </AccordionContent>
          </AccordionItem>
        );
      })}
    </Accordion>
  );
};

export default CategoryResultsComponent;