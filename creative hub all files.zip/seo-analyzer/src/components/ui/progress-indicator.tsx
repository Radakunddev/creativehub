import React from 'react';
import { AnalysisProgress } from '@/types';
import { Progress } from '@/components/ui/progress';
import { cn } from '@/lib/utils';

interface ProgressIndicatorProps {
  progress: AnalysisProgress;
}

const ProgressIndicator: React.FC<ProgressIndicatorProps> = ({ progress }) => {
  const { status, message, progress: value, currentTask } = progress;
  
  // 根据状态确定颜色
  const getStatusColor = () => {
    switch (status) {
      case 'loading':
      case 'analyzing':
        return 'text-blue-500';
      case 'completed':
        return 'text-green-500';
      case 'error':
        return 'text-red-500';
      default:
        return 'text-gray-500';
    }
  };
  
  // 根据状态确定进度条颜色
  const getProgressColor = () => {
    switch (status) {
      case 'loading':
      case 'analyzing':
        return 'bg-blue-500';
      case 'completed':
        return 'bg-green-500';
      case 'error':
        return 'bg-red-500';
      default:
        return 'bg-gray-300';
    }
  };
  
  return (
    <div className="w-full">
      <div className="flex justify-between items-center mb-1">
        <span className={cn("text-sm font-medium", getStatusColor())}>
          {message}
        </span>
        <span className="text-sm font-medium text-gray-700">
          {value}%
        </span>
      </div>
      
      <Progress 
        value={value} 
        className="h-2"
        indicatorClassName={getProgressColor()}
      />
      
      {currentTask && (
        <p className="text-xs text-gray-500 mt-1">
          {currentTask}
        </p>
      )}
    </div>
  );
};

export default ProgressIndicator;