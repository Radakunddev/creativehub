import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Label } from 'recharts';
import { getSeoScoreGrade } from '@/lib/seo-rules';

interface SeoScoreGaugeProps {
  score: number;
  maxScore: number;
  size?: 'sm' | 'md' | 'lg';
  showGrade?: boolean;
}

const SeoScoreGauge: React.FC<SeoScoreGaugeProps> = ({ 
  score, 
  maxScore, 
  size = 'md',
  showGrade = true
}) => {
  const percentage = Math.round((score / maxScore) * 100);
  const grade = getSeoScoreGrade(percentage);
  
  // 根据分数确定颜色
  const getScoreColor = () => {
    if (percentage >= 80) return '#22c55e'; // 绿色
    if (percentage >= 60) return '#f59e0b'; // 橙色
    return '#ef4444'; // 红色
  };
  
  // 根据尺寸确定大小
  const getSize = () => {
    if (size === 'sm') return 120;
    if (size === 'lg') return 200;
    return 160; // 默认中等大小
  };
  
  // 图表数据
  const data = [
    { name: 'Score', value: percentage },
    { name: 'Remaining', value: 100 - percentage }
  ];
  
  // 图表颜色
  const COLORS = [getScoreColor(), '#e5e7eb'];
  
  return (
    <div className="flex flex-col items-center">
      <div style={{ width: getSize(), height: getSize() }}>
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              startAngle={180}
              endAngle={0}
              innerRadius={getSize() * 0.55}
              outerRadius={getSize() * 0.7}
              paddingAngle={0}
              dataKey="value"
              strokeWidth={0}
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
              <Label
                value={`${percentage}%`}
                position="center"
                fill="#111827"
                style={{
                  fontSize: size === 'lg' ? '2rem' : size === 'md' ? '1.5rem' : '1rem',
                  fontWeight: 'bold'
                }}
              />
            </Pie>
          </PieChart>
        </ResponsiveContainer>
      </div>
      
      {showGrade && (
        <div className="mt-2 flex flex-col items-center">
          <span className="text-xl font-bold" style={{ color: getScoreColor() }}>
            {grade}
          </span>
          <span className="text-sm text-gray-500">
            {score} / {maxScore} 分
          </span>
        </div>
      )}
    </div>
  );
};

export default SeoScoreGauge;