import './App.css'
import SeoAnalyzer from '@/components/seo-analyzer/seo-analyzer'
import { MdOutlineAnalytics } from "react-icons/md";

function App() {
  return (
    <>
      <div className="flex min-h-screen flex-col">
        <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="container flex h-16 items-center">
            <div className="flex items-center space-x-2">
              <img src="/images/seo-logo.jpg" alt="SEO Analyzer Logo" className="h-8 w-8 rounded" />
              <span className="font-bold text-xl">SEO分析工具</span>
            </div>
            <nav className="ml-auto flex items-center space-x-6 text-sm font-medium">
              <a
                className="transition-colors hover:text-foreground/80 text-foreground flex items-center"
                href="#"
              >
                <MdOutlineAnalytics className="mr-1" />
                网站分析
              </a>
            </nav>
          </div>
        </header>
        <main className="flex-1 bg-gray-50">
          <section className="w-full py-8">
            <div className="container px-4 md:px-6">
              <div className="flex flex-col items-center justify-center mb-8 text-center">
                <div className="space-y-2">
                  <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                    全面SEO网站分析工具
                  </h1>
                  <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl">
                    分析您的网站SEO状况，获取专业优化建议，提升搜索引擎排名
                  </p>
                </div>
              </div>
              
              <SeoAnalyzer />
            </div>
          </section>
        </main>
        <footer className="w-full border-t py-6 md:py-0">
          <div className="container flex flex-col items-center justify-between gap-4 md:h-16 md:flex-row">
            <p className="text-sm text-gray-500">
              © 2025 SEO分析工具. 保留所有权利.
            </p>
            <div className="flex items-center gap-4">
              <a href="#" className="text-sm text-gray-500 hover:underline">
                隐私政策
              </a>
              <a href="#" className="text-sm text-gray-500 hover:underline">
                使用条款
              </a>
              <a href="#" className="text-sm text-gray-500 hover:underline">
                联系我们
              </a>
            </div>
          </div>
        </footer>
      </div>
    </>
  )
}

export default App
