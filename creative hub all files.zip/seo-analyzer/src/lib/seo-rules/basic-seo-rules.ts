import { ParsedPageData, SeoFactor } from '@/types';

/**
 * 基础SEO规则检查
 */
export const evaluateBasicSeoFactors = (pageData: ParsedPageData): SeoFactor[] => {
  const factors: SeoFactor[] = [];
  
  // 1. 标题检查
  const titleFactor = evaluateTitleTag(pageData);
  factors.push(titleFactor);
  
  // 2. Meta描述检查
  const metaDescriptionFactor = evaluateMetaDescription(pageData);
  factors.push(metaDescriptionFactor);
  
  // 3. Meta关键词检查
  const metaKeywordsFactor = evaluateMetaKeywords(pageData);
  factors.push(metaKeywordsFactor);
  
  // 4. URL结构检查
  const urlStructureFactor = evaluateUrlStructure(pageData);
  factors.push(urlStructureFactor);
  
  return factors;
};

/**
 * 评估页面标题
 */
const evaluateTitleTag = (pageData: ParsedPageData): SeoFactor => {
  const { title } = pageData;
  
  // 初始化分数
  let score = 0;
  const maxScore = 10;
  let status: SeoFactor['status'] = 'not-checked';
  const recommendations: string[] = [];
  
  // 检查标题是否存在
  if (!title) {
    status = 'poor';
    recommendations.push('添加一个描述性的页面标题，这是SEO的基础要素。');
    return {
      id: 'title-tag',
      name: '页面标题',
      category: 'basic',
      score,
      maxScore,
      status,
      details: '没有发现页面标题。标题对搜索引擎和用户体验至关重要。',
      recommendations,
      priority: 'high'
    };
  }
  
  // 检查标题长度 (Google通常显示50-60个字符)
  const titleLength = title.length;
  let lengthStatus = '';
  
  if (titleLength < 30) {
    lengthStatus = '标题过短';
    score += 3;
    recommendations.push('增加标题长度，理想长度为50-60个字符。');
  } else if (titleLength > 70) {
    lengthStatus = '标题过长';
    score += 5;
    recommendations.push('缩短标题长度，避免在搜索结果中被截断。理想长度为50-60个字符。');
  } else {
    lengthStatus = '标题长度适中';
    score += 8;
  }
  
  // 检查标题是否包含关键字
  // 这里我们假设标题中应包含页面内容中的主要关键词
  const hasKeywords = true; // 简化版，实际应分析标题中的关键词
  
  if (hasKeywords) {
    score += 2;
  } else {
    recommendations.push('在标题中包含页面相关的主要关键词，以提高搜索引擎的相关性判断。');
  }
  
  // 确定最终状态
  if (score >= 8) {
    status = 'excellent';
  } else if (score >= 6) {
    status = 'good';
  } else if (score >= 4) {
    status = 'needs-improvement';
  } else {
    status = 'poor';
  }
  
  return {
    id: 'title-tag',
    name: '页面标题',
    category: 'basic',
    score,
    maxScore,
    status,
    details: `标题: "${title}" (${titleLength}字符)。${lengthStatus}。`,
    recommendations,
    priority: 'high'
  };
};

/**
 * 评估Meta描述
 */
const evaluateMetaDescription = (pageData: ParsedPageData): SeoFactor => {
  const { metaDescription } = pageData;
  
  let score = 0;
  const maxScore = 10;
  let status: SeoFactor['status'] = 'not-checked';
  const recommendations: string[] = [];
  
  if (!metaDescription) {
    status = 'poor';
    recommendations.push('添加一个描述性的Meta描述，它会显示在搜索结果中并影响点击率。');
    return {
      id: 'meta-description',
      name: 'Meta描述',
      category: 'basic',
      score,
      maxScore,
      status,
      details: '没有发现Meta描述标签。Meta描述帮助用户理解页面内容并提高点击率。',
      recommendations,
      priority: 'high'
    };
  }
  
  // 检查描述长度 (Google通常显示约155-160个字符)
  const descLength = metaDescription.length;
  let lengthStatus = '';
  
  if (descLength < 70) {
    lengthStatus = 'Meta描述过短';
    score += 3;
    recommendations.push('增加Meta描述长度，理想长度为150-160个字符。');
  } else if (descLength > 170) {
    lengthStatus = 'Meta描述过长';
    score += 5;
    recommendations.push('缩短Meta描述，避免在搜索结果中被截断。理想长度为150-160个字符。');
  } else {
    lengthStatus = 'Meta描述长度适中';
    score += 8;
  }
  
  // 检查描述是否包含号召性用语
  const hasCallToAction = /查看|了解|购买|访问|联系|获取|发现|阅读/i.test(metaDescription);
  
  if (hasCallToAction) {
    score += 2;
  } else {
    recommendations.push('在Meta描述中添加行动号召语，如"了解更多"、"立即查看"等，以提高点击率。');
  }
  
  // 确定最终状态
  if (score >= 8) {
    status = 'excellent';
  } else if (score >= 6) {
    status = 'good';
  } else if (score >= 4) {
    status = 'needs-improvement';
  } else {
    status = 'poor';
  }
  
  return {
    id: 'meta-description',
    name: 'Meta描述',
    category: 'basic',
    score,
    maxScore,
    status,
    details: `Meta描述: "${metaDescription.substring(0, 100)}${metaDescription.length > 100 ? '...' : ''}" (${descLength}字符)。${lengthStatus}。`,
    recommendations,
    priority: 'high'
  };
};

/**
 * 评估Meta关键词
 */
const evaluateMetaKeywords = (pageData: ParsedPageData): SeoFactor => {
  const { metaKeywords } = pageData;
  
  let score = 0;
  const maxScore = 5; // 较低的分值，因为meta keywords在现代SEO中重要性降低
  let status: SeoFactor['status'] = 'not-checked';
  const recommendations: string[] = [];
  
  // 检查关键词是否存在
  if (!metaKeywords || metaKeywords.length === 0) {
    status = 'needs-improvement';
    recommendations.push('虽然Meta关键词标签对大多数搜索引擎的影响有限，但添加相关关键词仍可能对某些搜索引擎有帮助。');
    
    return {
      id: 'meta-keywords',
      name: 'Meta关键词',
      category: 'basic',
      score: 2, // 基础分数，因为缺少关键词在现代SEO中不是严重问题
      maxScore,
      status,
      details: '没有发现Meta关键词标签。虽然此标签对大部分搜索引擎的权重已经降低，但对某些搜索引擎仍有参考价值。',
      recommendations,
      priority: 'low'
    };
  }
  
  // 检查关键词数量 (理想为5-10个)
  const keywordCount = metaKeywords.length;
  
  if (keywordCount < 3) {
    score += 2;
    recommendations.push('增加Meta关键词数量，建议使用5-8个相关关键词。');
  } else if (keywordCount > 10) {
    score += 3;
    recommendations.push('减少Meta关键词数量，过多关键词可能被视为关键词堆砌。建议使用5-8个相关关键词。');
  } else {
    score += 5;
  }
  
  // 确定最终状态
  if (score >= 4) {
    status = 'good';
  } else if (score >= 2) {
    status = 'needs-improvement';
  } else {
    status = 'poor';
  }
  
  return {
    id: 'meta-keywords',
    name: 'Meta关键词',
    category: 'basic',
    score,
    maxScore,
    status,
    details: `发现${keywordCount}个Meta关键词: ${metaKeywords.join(', ')}`,
    recommendations,
    priority: 'low'
  };
};

/**
 * 评估URL结构
 */
const evaluateUrlStructure = (pageData: ParsedPageData): SeoFactor => {
  const { url } = pageData;
  
  let score = 0;
  const maxScore = 10;
  let status: SeoFactor['status'] = 'not-checked';
  const recommendations: string[] = [];
  
  // 检查URL是否过长 (理想URL长度小于100字符)
  const urlLength = url.length;
  
  if (urlLength > 100) {
    score += 2;
    recommendations.push('缩短URL长度，简短的URL更利于用户记忆和分享。');
  } else if (urlLength > 75) {
    score += 5;
    recommendations.push('考虑缩短URL，更简洁的URL对用户和搜索引擎更友好。');
  } else {
    score += 7;
  }
  
  // 检查URL是否包含特殊字符
  const hasSpecialChars = /[^a-zA-Z0-9-_.~/]/g.test(url);
  
  if (hasSpecialChars) {
    recommendations.push('移除URL中的特殊字符，使用连字符(-)代替空格，保持URL简洁可读。');
  } else {
    score += 3;
  }
  
  // 检查URL是否使用连字符(-)而不是下划线(_)
  const hasUnderscores = url.includes('_');
  
  if (hasUnderscores) {
    recommendations.push('使用连字符(-)代替下划线(_)，这是搜索引擎推荐的做法。');
  }
  
  // 确定最终状态
  if (score >= 8) {
    status = 'excellent';
  } else if (score >= 6) {
    status = 'good';
  } else if (score >= 4) {
    status = 'needs-improvement';
  } else {
    status = 'poor';
  }
  
  return {
    id: 'url-structure',
    name: 'URL结构',
    category: 'basic',
    score,
    maxScore,
    status,
    details: `URL: ${url} (${urlLength}字符)`,
    recommendations,
    priority: 'medium'
  };
};