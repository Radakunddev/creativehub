import { ParsedPageData, SeoFactor } from '@/types';

/**
 * 高级SEO规则检查
 */
export const evaluateAdvancedSeoFactors = (pageData: ParsedPageData): SeoFactor[] => {
  const factors: SeoFactor[] = [];
  
  // 1. 结构化数据检查
  const structuredDataFactor = evaluateStructuredData(pageData);
  factors.push(structuredDataFactor);
  
  // 2. 社交媒体标签检查
  const socialTagsFactor = evaluateSocialTags(pageData);
  factors.push(socialTagsFactor);
  
  // 3. 网站地图检查（模拟）
  const sitemapFactor = evaluateSitemap(pageData);
  factors.push(sitemapFactor);
  
  // 4. Robots.txt检查（模拟）
  const robotsTxtFactor = evaluateRobotsTxt(pageData);
  factors.push(robotsTxtFactor);
  
  // 5. 页面重定向检查（模拟）
  const redirectsFactor = evaluateRedirects(pageData);
  factors.push(redirectsFactor);
  
  return factors;
};

/**
 * 评估结构化数据
 */
const evaluateStructuredData = (pageData: ParsedPageData): SeoFactor => {
  const { structuredData } = pageData;
  
  let score = 0;
  const maxScore = 10;
  let status: SeoFactor['status'] = 'not-checked';
  const recommendations: string[] = [];
  
  if (!structuredData || structuredData.length === 0) {
    status = 'needs-improvement';
    recommendations.push('添加结构化数据(Schema.org)标记以帮助搜索引擎更好地理解页面内容。');
    recommendations.push('考虑添加适合您内容类型的结构化数据，如Article、Product、LocalBusiness、FAQ等。');
    
    return {
      id: 'structured-data',
      name: '结构化数据',
      category: 'advanced',
      score: 0,
      maxScore,
      status,
      details: '未发现结构化数据标记。结构化数据可以使您的页面在搜索结果中显示更丰富的信息。',
      recommendations,
      priority: 'medium'
    };
  }
  
  // 检测结构化数据类型
  const schemaTypes = structuredData.map(schema => {
    if (typeof schema === 'object' && schema !== null) {
      return schema['@type'] || '未知类型';
    }
    return '未知类型';
  });
  
  score = 8; // 有结构化数据就给较高分数
  status = 'excellent';
  
  // 通用建议
  recommendations.push('使用Google的结构化数据测试工具验证您的结构化数据是否正确实现。');
  recommendations.push('考虑扩展结构化数据，包含更多详细信息，以增加获得富摘要显示的机会。');
  
  return {
    id: 'structured-data',
    name: '结构化数据',
    category: 'advanced',
    score,
    maxScore,
    status,
    details: `发现${structuredData.length}个结构化数据块，类型包括: ${schemaTypes.join(', ')}`,
    recommendations,
    priority: 'medium'
  };
};

/**
 * 评估社交媒体标签
 */
const evaluateSocialTags = (pageData: ParsedPageData): SeoFactor => {
  const { openGraphTags, twitterCards } = pageData;
  
  let score = 0;
  const maxScore = 10;
  let status: SeoFactor['status'] = 'not-checked';
  const recommendations: string[] = [];
  
  const hasOpenGraph = openGraphTags && Object.keys(openGraphTags).length > 0;
  const hasTwitterCards = twitterCards && Object.keys(twitterCards).length > 0;
  
  // 检查Open Graph标签
  if (hasOpenGraph) {
    const hasBasicOgTags = 
      openGraphTags['title'] && 
      openGraphTags['description'] && 
      openGraphTags['image'];
    
    if (hasBasicOgTags) {
      score += 5;
    } else {
      score += 2;
      recommendations.push('完善Open Graph标签，确保包含基本标签：og:title, og:description, og:image 和 og:url。');
    }
  } else {
    recommendations.push('添加Open Graph标签，以便在Facebook等社交媒体平台上优化内容的显示方式。');
  }
  
  // 检查Twitter Cards
  if (hasTwitterCards) {
    const hasBasicTwitterTags =
      twitterCards['card'] &&
      (twitterCards['title'] || openGraphTags['title']) &&
      (twitterCards['description'] || openGraphTags['description']);
    
    if (hasBasicTwitterTags) {
      score += 5;
    } else {
      score += 2;
      recommendations.push('完善Twitter Card标签，确保包含twitter:card, twitter:title, twitter:description 和 twitter:image。');
    }
  } else {
    recommendations.push('添加Twitter Card标签，以优化内容在Twitter上的显示方式。');
  }
  
  // 确定最终状态
  if (score >= 8) {
    status = 'excellent';
  } else if (score >= 5) {
    status = 'good';
  } else if (score >= 3) {
    status = 'needs-improvement';
  } else {
    status = 'poor';
  }
  
  return {
    id: 'social-tags',
    name: '社交媒体标签',
    category: 'advanced',
    score,
    maxScore,
    status,
    details: `${hasOpenGraph ? '已实现' : '未实现'} Open Graph标签，${hasTwitterCards ? '已实现' : '未实现'} Twitter Cards。`,
    recommendations,
    priority: 'medium'
  };
};

/**
 * 评估网站地图
 * 注意：这是模拟检查，客户端无法直接访问网站地图
 */
const evaluateSitemap = (pageData: ParsedPageData): SeoFactor => {
  // 在客户端我们无法检查网站地图，除非网站地图URL在页面中有链接
  // 这里提供一个通用建议
  
  let score = 2; // 默认低分
  const maxScore = 5;
  let status: SeoFactor['status'] = 'needs-improvement';
  const recommendations: string[] = [];
  
  recommendations.push('确保您的网站有XML网站地图，并已提交给搜索引擎。');
  recommendations.push('网站地图应包含所有重要页面，并定期更新。');
  recommendations.push('检查网站地图是否在robots.txt文件中引用。');
  
  return {
    id: 'sitemap',
    name: '网站地图',
    category: 'advanced',
    score,
    maxScore,
    status,
    details: '无法从客户端检查网站地图。网站地图帮助搜索引擎发现和索引您的所有页面。',
    recommendations,
    priority: 'medium'
  };
};

/**
 * 评估Robots.txt
 * 注意：这是模拟检查，客户端无法直接访问robots.txt
 */
const evaluateRobotsTxt = (pageData: ParsedPageData): SeoFactor => {
  // 在客户端我们无法检查robots.txt，这里提供通用建议
  
  let score = 2; // 默认低分
  const maxScore = 5;
  let status: SeoFactor['status'] = 'needs-improvement';
  const recommendations: string[] = [];
  
  recommendations.push('确保您的网站有正确配置的robots.txt文件。');
  recommendations.push('检查robots.txt是否阻止了重要内容被搜索引擎访问。');
  recommendations.push('确保robots.txt引用了您的网站地图位置。');
  
  return {
    id: 'robots-txt',
    name: 'Robots.txt',
    category: 'advanced',
    score,
    maxScore,
    status,
    details: '无法从客户端检查robots.txt。Robots.txt文件指导搜索引擎如何爬取您的网站。',
    recommendations,
    priority: 'medium'
  };
};

/**
 * 评估页面重定向
 * 注意：这是模拟检查，客户端难以检测所有重定向
 */
const evaluateRedirects = (pageData: ParsedPageData): SeoFactor => {
  // 在客户端我们无法检测所有重定向，这里提供通用建议
  
  let score = 3; // 默认中低分
  const maxScore = 5;
  let status: SeoFactor['status'] = 'good';
  const recommendations: string[] = [];
  
  recommendations.push('确保使用301重定向而不是302重定向进行永久性URL更改。');
  recommendations.push('避免重定向链（多次重定向）,这会增加页面加载时间。');
  recommendations.push('检查网站是否同时可通过www和非www版本访问，并将一个版本重定向到另一个版本。');
  
  return {
    id: 'redirects',
    name: '页面重定向',
    category: 'advanced',
    score,
    maxScore,
    status,
    details: '无法从客户端全面检查重定向。适当的重定向策略有助于保留链接权重并提供良好的用户体验。',
    recommendations,
    priority: 'low'
  };
};