import { ParsedPageData, SeoFactor } from '@/types';

/**
 * 内容SEO规则检查
 */
export const evaluateContentSeoFactors = (pageData: ParsedPageData): SeoFactor[] => {
  const factors: SeoFactor[] = [];
  
  // 1. 标题结构检查
  const headingStructureFactor = evaluateHeadingStructure(pageData);
  factors.push(headingStructureFactor);
  
  // 2. 内容长度检查
  const contentLengthFactor = evaluateContentLength(pageData);
  factors.push(contentLengthFactor);
  
  // 3. 关键词密度分析
  const keywordDensityFactor = evaluateKeywordDensity(pageData);
  factors.push(keywordDensityFactor);
  
  // 4. 内容质量评估
  const contentQualityFactor = evaluateContentQuality(pageData);
  factors.push(contentQualityFactor);
  
  return factors;
};

/**
 * 评估标题结构
 */
const evaluateHeadingStructure = (pageData: ParsedPageData): SeoFactor => {
  const { h1Tags, h2Tags, h3Tags, h4Tags, h5Tags, h6Tags } = pageData;
  
  let score = 0;
  const maxScore = 15;
  let status: SeoFactor['status'] = 'not-checked';
  const recommendations: string[] = [];
  
  // 检查H1标签
  const h1Count = h1Tags.length;
  
  if (h1Count === 0) {
    recommendations.push('添加一个H1标签作为页面的主标题，每个页面应该有一个明确的H1标签。');
  } else if (h1Count === 1) {
    score += 5; // 理想情况：一个H1标签
  } else {
    score += 2;
    recommendations.push('每个页面应该只有一个H1标签。多个H1标签可能会混淆搜索引擎对页面主题的理解。');
  }
  
  // 检查是否使用了H2子标题
  if (h2Tags.length === 0) {
    recommendations.push('添加H2标签作为内容的子标题，以便组织内容结构。');
  } else {
    score += 3;
  }
  
  // 检查标题层次结构
  const hasProperHierarchy = 
    (h1Count <= 1) && // 最多一个H1
    (h3Tags.length === 0 || h2Tags.length > 0) && // 如果有H3，则应该有H2
    (h4Tags.length === 0 || h3Tags.length > 0) && // 如果有H4，则应该有H3
    (h5Tags.length === 0 || h4Tags.length > 0) && // 如果有H5，则应该有H4
    (h6Tags.length === 0 || h5Tags.length > 0);   // 如果有H6，则应该有H5
  
  if (hasProperHierarchy) {
    score += 5;
  } else {
    recommendations.push('保持标题标签的层次结构，不要跳过层级（例如，H1后直接使用H3而不是H2）。');
  }
  
  // 检查标题数量是否合理
  const totalHeadings = h1Count + h2Tags.length + h3Tags.length + h4Tags.length + h5Tags.length + h6Tags.length;
  const contentSize = pageData.wordCount;
  const headingDensity = contentSize > 0 ? totalHeadings / (contentSize / 100) : 0;
  
  if (contentSize > 300 && headingDensity < 0.5) {
    recommendations.push('增加标题标签的使用，每300-500字应该有一个标题，以便提高内容的可读性。');
  } else if (headingDensity > 2) {
    recommendations.push('减少标题标签的使用，过多的标题可能会使内容结构混乱。');
  } else {
    score += 2;
  }
  
  // 确定最终状态
  if (score >= 12) {
    status = 'excellent';
  } else if (score >= 8) {
    status = 'good';
  } else if (score >= 5) {
    status = 'needs-improvement';
  } else {
    status = 'poor';
  }
  
  return {
    id: 'heading-structure',
    name: '标题结构',
    category: 'content',
    score,
    maxScore,
    status,
    details: `H1: ${h1Count}个, H2: ${h2Tags.length}个, H3: ${h3Tags.length}个, H4: ${h4Tags.length}个, H5: ${h5Tags.length}个, H6: ${h6Tags.length}个`,
    recommendations,
    priority: 'high'
  };
};

/**
 * 评估内容长度
 */
const evaluateContentLength = (pageData: ParsedPageData): SeoFactor => {
  const { wordCount } = pageData;
  
  let score = 0;
  const maxScore = 10;
  let status: SeoFactor['status'] = 'not-checked';
  const recommendations: string[] = [];
  
  // 基于字数评估内容长度
  if (wordCount < 300) {
    score += 2;
    recommendations.push('增加页面内容长度，搜索引擎通常更喜欢内容丰富的页面。建议至少达到600字。');
    status = 'poor';
  } else if (wordCount < 600) {
    score += 5;
    recommendations.push('考虑增加更多高质量内容，理想的内容长度在1000-1500字左右。');
    status = 'needs-improvement';
  } else if (wordCount < 1000) {
    score += 7;
    status = 'good';
  } else {
    score += 10;
    status = 'excellent';
  }
  
  return {
    id: 'content-length',
    name: '内容长度',
    category: 'content',
    score,
    maxScore,
    status,
    details: `页面内容包含约${wordCount}个字。${wordCount >= 1000 ? '内容长度充分，有助于提供全面的信息。' : ''}`,
    recommendations,
    priority: 'medium'
  };
};

/**
 * 评估关键词密度
 * 注意：这是一个简化版本，完整版本需要进行更复杂的文本分析
 */
const evaluateKeywordDensity = (pageData: ParsedPageData): SeoFactor => {
  // 这里我们假设标题中包含的词是主关键词
  // 实际应用中，应该使用更复杂的算法来确定页面的主关键词
  
  const { title } = pageData;
  
  let score = 0;
  const maxScore = 10;
  let status: SeoFactor['status'] = 'not-checked';
  const recommendations: string[] = [];
  
  // 由于我们没有实际分析关键词密度，这里提供一个通用建议
  score = 5; // 中等分数
  status = 'good';
  
  recommendations.push('确保页面内容自然地包含主要关键词，理想的关键词密度在1.5%-2.5%之间。');
  recommendations.push('在标题、副标题、开头段落和结尾段落中适当包含关键词变体。');
  
  return {
    id: 'keyword-density',
    name: '关键词密度',
    category: 'content',
    score,
    maxScore,
    status,
    details: '关键词密度分析需要专业的内容分析工具。理想的关键词密度应保持在1.5%-2.5%之间，确保内容自然流畅。',
    recommendations,
    priority: 'medium'
  };
};

/**
 * 评估内容质量
 * 注意：完整评估内容质量需要更复杂的分析
 */
const evaluateContentQuality = (pageData: ParsedPageData): SeoFactor => {
  const { paragraphs } = pageData;
  
  let score = 0;
  const maxScore = 10;
  let status: SeoFactor['status'] = 'not-checked';
  const recommendations: string[] = [];
  
  // 段落数量检查
  if (paragraphs < 3) {
    score += 2;
    recommendations.push('增加内容的段落数量，短小的段落更易于阅读。');
  } else if (paragraphs < 5) {
    score += 5;
    recommendations.push('考虑增加更多段落，提高内容的可读性。');
  } else {
    score += 7;
  }
  
  // 通用建议
  recommendations.push('确保内容原创、有价值，避免重复或抄袭的内容。');
  recommendations.push('使用列表、图表、图片等元素增强内容的可读性和吸引力。');
  
  // 确定最终状态
  if (score >= 8) {
    status = 'excellent';
  } else if (score >= 6) {
    status = 'good';
  } else if (score >= 4) {
    status = 'needs-improvement';
  } else {
    status = 'poor';
  }
  
  return {
    id: 'content-quality',
    name: '内容质量',
    category: 'content',
    score,
    maxScore,
    status,
    details: `内容包含${paragraphs}个段落。高质量内容应该信息丰富、结构清晰、易于阅读。`,
    recommendations,
    priority: 'high'
  };
};