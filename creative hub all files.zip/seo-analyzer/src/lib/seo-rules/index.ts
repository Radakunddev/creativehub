import { AnalysisResult, CategoryResults, ParsedPageData, SeoFactor } from '@/types';
import { evaluateBasicSeoFactors } from './basic-seo-rules';
import { evaluateContentSeoFactors } from './content-seo-rules';
import { evaluateTechnicalSeoFactors } from './technical-seo-rules';
import { evaluateAdvancedSeoFactors } from './advanced-seo-rules';

/**
 * 运行完整的SEO分析
 */
export const runSeoAnalysis = (
  url: string, 
  pageData: ParsedPageData, 
  htmlContent: string
): AnalysisResult => {
  // 收集所有因素
  const basicFactors = evaluateBasicSeoFactors(pageData);
  const contentFactors = evaluateContentSeoFactors(pageData);
  const technicalFactors = evaluateTechnicalSeoFactors(pageData);
  const advancedFactors = evaluateAdvancedSeoFactors(pageData);
  
  const allFactors = [
    ...basicFactors,
    ...contentFactors,
    ...technicalFactors,
    ...advancedFactors
  ];
  
  // 计算总分
  const totalScore = allFactors.reduce((sum, factor) => sum + factor.score, 0);
  const maxPossibleScore = allFactors.reduce((sum, factor) => sum + factor.maxScore, 0);
  
  // 创建分析结果
  const result: AnalysisResult = {
    url,
    timestamp: new Date().toISOString(),
    totalScore,
    maxPossibleScore,
    factors: allFactors,
    htmlContent
  };
  
  return result;
};

/**
 * 按类别对分析结果进行分组
 */
export const groupResultsByCategory = (result: AnalysisResult): CategoryResults => {
  const categories: CategoryResults = {};
  
  for (const factor of result.factors) {
    const { category } = factor;
    
    if (!categories[category]) {
      categories[category] = {
        factors: [],
        score: 0,
        maxScore: 0,
        percentage: 0
      };
    }
    
    categories[category].factors.push(factor);
    categories[category].score += factor.score;
    categories[category].maxScore += factor.maxScore;
  }
  
  // 计算每个类别的百分比
  for (const category in categories) {
    const { score, maxScore } = categories[category];
    categories[category].percentage = maxScore > 0 
      ? (score / maxScore) * 100 
      : 0;
  }
  
  return categories;
};

/**
 * 获取SEO得分等级
 */
export const getSeoScoreGrade = (percentage: number): string => {
  if (percentage >= 90) return 'A+';
  if (percentage >= 80) return 'A';
  if (percentage >= 70) return 'B+';
  if (percentage >= 60) return 'B';
  if (percentage >= 50) return 'C+';
  if (percentage >= 40) return 'C';
  if (percentage >= 30) return 'D';
  return 'F';
};

/**
 * 将因素按优先级排序
 */
export const sortFactorsByPriority = (factors: SeoFactor[]): SeoFactor[] => {
  const priorityOrder = { 'high': 0, 'medium': 1, 'low': 2 };
  
  return [...factors].sort((a, b) => {
    // 首先按优先级排序
    const priorityDiff = priorityOrder[a.priority] - priorityOrder[b.priority];
    if (priorityDiff !== 0) return priorityDiff;
    
    // 然后按状态排序（从最差到最好）
    const statusOrder = { 'poor': 0, 'needs-improvement': 1, 'good': 2, 'excellent': 3, 'not-checked': 4 };
    return statusOrder[a.status] - statusOrder[b.status];
  });
};