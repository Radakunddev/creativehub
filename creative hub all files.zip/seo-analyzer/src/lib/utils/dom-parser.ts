import { ParsedPageData } from '@/types';

/**
 * 从HTML字符串中解析出SEO相关的页面数据
 */
export const parseHtmlContent = (html: string, url: string): ParsedPageData => {
  // 创建一个DOMParser实例
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, 'text/html');
  
  // 提取基本信息
  const title = doc.title || '';
  
  // 获取meta描述
  const metaDescription = doc.querySelector('meta[name="description"]')?.getAttribute('content') || 
                         doc.querySelector('meta[property="og:description"]')?.getAttribute('content') || '';
  
  // 获取meta关键词
  const metaKeywordsContent = doc.querySelector('meta[name="keywords"]')?.getAttribute('content') || '';
  const metaKeywords = metaKeywordsContent ? metaKeywordsContent.split(',').map(k => k.trim()) : [];
  
  // 提取所有标题标签
  const h1Tags = Array.from(doc.querySelectorAll('h1')).map(tag => tag.textContent?.trim() || '');
  const h2Tags = Array.from(doc.querySelectorAll('h2')).map(tag => tag.textContent?.trim() || '');
  const h3Tags = Array.from(doc.querySelectorAll('h3')).map(tag => tag.textContent?.trim() || '');
  const h4Tags = Array.from(doc.querySelectorAll('h4')).map(tag => tag.textContent?.trim() || '');
  const h5Tags = Array.from(doc.querySelectorAll('h5')).map(tag => tag.textContent?.trim() || '');
  const h6Tags = Array.from(doc.querySelectorAll('h6')).map(tag => tag.textContent?.trim() || '');
  
  // 提取段落数和字数
  const paragraphs = doc.querySelectorAll('p').length;
  const textContent = doc.body?.textContent || '';
  const wordCount = textContent.trim().split(/\s+/).filter(Boolean).length;
  
  // 提取链接
  const allLinks = Array.from(doc.querySelectorAll('a[href]'));
  
  const targetUrl = new URL(url.startsWith('http') ? url : `https://${url}`);
  const targetHostname = targetUrl.hostname;
  
  const internalLinks = allLinks
    .map(link => link.getAttribute('href') || '')
    .filter(href => {
      if (!href || href.startsWith('#') || href === '/') return false;
      
      try {
        const linkUrl = new URL(href, targetUrl.href);
        return linkUrl.hostname === targetHostname;
      } catch {
        return href.startsWith('/');
      }
    });
  
  const externalLinks = allLinks
    .map(link => link.getAttribute('href') || '')
    .filter(href => {
      if (!href || href.startsWith('#') || href === '/') return false;
      
      try {
        const linkUrl = new URL(href, targetUrl.href);
        return linkUrl.hostname !== targetHostname;
      } catch {
        return false;
      }
    });
  
  // 提取图片信息
  const allImages = Array.from(doc.querySelectorAll('img'));
  const imagesWithAlt = allImages.filter(img => img.hasAttribute('alt') && img.getAttribute('alt')?.trim());
  const imagesWithoutAlt = allImages.filter(img => !img.hasAttribute('alt') || !img.getAttribute('alt')?.trim());
  const altTexts = allImages
    .map(img => img.getAttribute('alt'))
    .filter((alt): alt is string => alt !== null && alt.trim() !== '');
  
  // 提取结构化数据
  const structuredData: any[] = [];
  const scriptTags = Array.from(doc.querySelectorAll('script[type="application/ld+json"]'));
  scriptTags.forEach(script => {
    try {
      if (script.textContent) {
        const jsonData = JSON.parse(script.textContent);
        structuredData.push(jsonData);
      }
    } catch (e) {
      console.error('解析结构化数据失败:', e);
    }
  });
  
  // 提取Open Graph标签
  const openGraphTags: any = {};
  const ogTags = Array.from(doc.querySelectorAll('meta[property^="og:"]'));
  ogTags.forEach(tag => {
    const property = tag.getAttribute('property');
    const content = tag.getAttribute('content');
    if (property && content) {
      openGraphTags[property.replace('og:', '')] = content;
    }
  });
  
  // 提取Twitter Cards
  const twitterCards: any = {};
  const twitterTags = Array.from(doc.querySelectorAll('meta[name^="twitter:"]'));
  twitterTags.forEach(tag => {
    const name = tag.getAttribute('name');
    const content = tag.getAttribute('content');
    if (name && content) {
      twitterCards[name.replace('twitter:', '')] = content;
    }
  });
  
  // 检查HTTPS
  const hasHttps = url.startsWith('https://');
  
  return {
    title,
    metaDescription,
    metaKeywords,
    h1Tags,
    h2Tags,
    h3Tags,
    h4Tags,
    h5Tags,
    h6Tags,
    paragraphs,
    wordCount,
    internalLinks,
    externalLinks,
    images: {
      total: allImages.length,
      withAlt: imagesWithAlt.length,
      withoutAlt: imagesWithoutAlt.length,
      altTexts
    },
    structuredData,
    openGraphTags,
    twitterCards,
    hasHttps,
    url
  };
};