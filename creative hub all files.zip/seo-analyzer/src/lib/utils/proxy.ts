import axios from 'axios';

/**
 * 使用模拟数据进行SEO分析
 * 由于CORS限制，我们在客户端无法直接抓取其他网站的内容
 * 因此使用模拟HTML数据进行演示
 */
export const fetchWebsiteContent = async (url: string): Promise<string> => {
  try {
    // 确保URL格式正确
    const targetUrl = url.startsWith('http') ? url : `https://${url}`;
    
    // 返回模拟HTML数据
    // 在实际应用中，这里应该通过服务器端代理或API获取实际网站内容
    console.log(`模拟获取网站内容: ${targetUrl}`);
    
    // 基于URL生成不同的模拟数据，使分析结果看起来更真实
    return generateMockHtml(targetUrl);
    
  } catch (error) {
    console.error('获取网站内容失败:', error);
    throw new Error(`无法获取网站内容: ${error instanceof Error ? error.message : '未知错误'}`);
  }
};

/**
 * 检查URL格式是否有效
 */
export const isValidUrl = (url: string): boolean => {
  try {
    // 添加协议如果没有
    const urlToCheck = url.startsWith('http') ? url : `https://${url}`;
    new URL(urlToCheck);
    return true;
  } catch (e) {
    return false;
  }
};

/**
 * 生成模拟HTML数据用于演示
 */
const generateMockHtml = (url: string): string => {
  // 从URL中提取域名
  const domain = new URL(url).hostname;
  
  // 基本模板
  const mockHtml = `
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${domain} - 示例网站</title>
  <meta name="description" content="这是${domain}的网站描述，包含各种相关信息和服务介绍。">
  <meta name="keywords" content="关键词1, 关键词2, ${domain}, 示例">
  
  <!-- Open Graph 标签 -->
  <meta property="og:title" content="${domain} - 社交媒体标题">
  <meta property="og:description" content="${domain}的社交媒体描述">
  <meta property="og:image" content="https://example.com/image.jpg">
  <meta property="og:url" content="${url}">
  
  <!-- Twitter Cards -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="${domain} - 推特卡片标题">
  
  <!-- 结构化数据 -->
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "Organization",
    "name": "${domain} 公司",
    "url": "${url}",
    "logo": "https://example.com/logo.png"
  }
  </script>
</head>
<body>
  <header>
    <h1>${domain} 官方网站</h1>
    <nav>
      <ul>
        <li><a href="/">首页</a></li>
        <li><a href="/about">关于我们</a></li>
        <li><a href="/products">产品</a></li>
        <li><a href="/services">服务</a></li>
        <li><a href="/contact">联系我们</a></li>
      </ul>
    </nav>
  </header>
  
  <main>
    <section>
      <h2>欢迎访问我们的网站</h2>
      <p>这是一个示例段落，提供了关于${domain}的基本信息。我们提供各种服务和产品，满足客户的不同需求。</p>
      <p>这是另一个段落，进一步描述我们的业务和专业知识。我们致力于为客户提供最高质量的服务和解决方案。</p>
    </section>
    
    <section>
      <h2>我们的产品</h2>
      <div class="products">
        <article>
          <h3>产品一</h3>
          <img src="/product1.jpg" alt="产品一图片">
          <p>产品一的详细描述和特点介绍。这是一个高质量的产品，具有多种功能。</p>
        </article>
        
        <article>
          <h3>产品二</h3>
          <img src="/product2.jpg" alt="产品二图片">
          <p>产品二的详细描述和特点介绍。这是我们的畅销产品，深受客户喜爱。</p>
        </article>
      </div>
    </section>
    
    <section>
      <h2>最新动态</h2>
      <article>
        <h3>公司新闻标题</h3>
        <p>公司最新动态和新闻的详细内容。我们最近取得了重要进展和成就。</p>
        <a href="/news/1">阅读更多</a>
      </article>
    </section>
  </main>
  
  <footer>
    <div class="footer-links">
      <div>
        <h4>关于我们</h4>
        <ul>
          <li><a href="/about/history">公司历史</a></li>
          <li><a href="/about/team">团队介绍</a></li>
          <li><a href="/about/vision">愿景使命</a></li>
        </ul>
      </div>
      
      <div>
        <h4>服务</h4>
        <ul>
          <li><a href="/services/consulting">咨询服务</a></li>
          <li><a href="/services/development">开发服务</a></li>
          <li><a href="/services/support">技术支持</a></li>
        </ul>
      </div>
      
      <div>
        <h4>联系我们</h4>
        <address>
          地址: 中国北京市朝阳区某某街道100号<br>
          电话: 010-12345678<br>
          邮箱: <a href="mailto:info@${domain}">info@${domain}</a>
        </address>
      </div>
    </div>
    
    <div class="social-links">
      <a href="https://facebook.com/" target="_blank">Facebook</a>
      <a href="https://twitter.com/" target="_blank">Twitter</a>
      <a href="https://linkedin.com/" target="_blank">LinkedIn</a>
      <a href="https://instagram.com/" target="_blank">Instagram</a>
    </div>
    
    <p>&copy; 2025 ${domain} 版权所有</p>
  </footer>
</body>
</html>
  `;
  
  return mockHtml;
};