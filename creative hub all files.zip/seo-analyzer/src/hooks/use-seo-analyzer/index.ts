import { useState, useCallback } from 'react';
import { AnalysisProgress, AnalysisResult, CategoryResults } from '@/types';
import { fetchWebsiteContent, isValidUrl } from '@/lib/utils/proxy';
import { parseHtmlContent } from '@/lib/utils/dom-parser';
import { groupResultsByCategory, runSeoAnalysis } from '@/lib/seo-rules';

/**
 * 用于进行SEO分析的钩子
 */
export const useSeoAnalyzer = () => {
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [categoryResults, setCategoryResults] = useState<CategoryResults | null>(null);
  const [progress, setProgress] = useState<AnalysisProgress>({
    status: 'idle',
    message: '准备分析',
    progress: 0
  });
  const [error, setError] = useState<string | null>(null);
  
  /**
   * 重置分析状态
   */
  const resetAnalysis = useCallback(() => {
    setAnalysisResult(null);
    setCategoryResults(null);
    setProgress({
      status: 'idle',
      message: '准备分析',
      progress: 0
    });
    setError(null);
  }, []);
  
  /**
   * 运行SEO分析
   */
  const analyzeSeo = useCallback(async (url: string) => {
    try {
      // 重置之前的结果
      resetAnalysis();
      
      // 验证URL
      if (!isValidUrl(url)) {
        setError('请输入有效的URL');
        return;
      }
      
      // 更新进度状态为加载中
      setProgress({
        status: 'loading',
        message: '正在获取网页内容...',
        progress: 10
      });
      
      // 获取网页内容
      const normalizedUrl = url.startsWith('http') ? url : `https://${url}`;
      const htmlContent = await fetchWebsiteContent(normalizedUrl);
      
      // 更新进度状态为分析中
      setProgress({
        status: 'analyzing',
        message: '正在分析页面内容...',
        progress: 40,
        currentTask: '解析DOM结构'
      });
      
      // 解析网页内容
      const pageData = parseHtmlContent(htmlContent, normalizedUrl);
      
      setProgress({
        status: 'analyzing',
        message: '正在评估SEO因素...',
        progress: 70,
        currentTask: '应用SEO规则'
      });
      
      // 运行SEO分析
      const result = runSeoAnalysis(normalizedUrl, pageData, htmlContent);
      
      // 按类别分组结果
      const groupedResults = groupResultsByCategory(result);
      
      // 设置结果
      setAnalysisResult(result);
      setCategoryResults(groupedResults);
      
      // 更新进度状态为完成
      setProgress({
        status: 'completed',
        message: '分析完成',
        progress: 100
      });
      
      return result;
    } catch (err) {
      console.error('SEO分析失败:', err);
      setError(`分析失败: ${err instanceof Error ? err.message : '未知错误'}`);
      
      setProgress({
        status: 'error',
        message: '分析过程中出现错误',
        progress: 0
      });
      
      return null;
    }
  }, [resetAnalysis]);
  
  return {
    analyzeSeo,
    resetAnalysis,
    analysisResult,
    categoryResults,
    progress,
    error
  };
};

export default useSeoAnalyzer;