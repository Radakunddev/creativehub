// SEO分析项目类型
export interface SeoFactor {
  id: string;
  name: string;
  category: SeoCategory;
  score: number;
  maxScore: number;
  status: 'excellent' | 'good' | 'needs-improvement' | 'poor' | 'not-checked';
  details: string;
  recommendations: string[];
  priority: 'high' | 'medium' | 'low';
}

// SEO分析类别
export type SeoCategory = 
  | 'basic' 
  | 'content' 
  | 'technical' 
  | 'advanced';

// 分析结果类型
export interface AnalysisResult {
  url: string;
  timestamp: string;
  totalScore: number;
  maxPossibleScore: number;
  factors: SeoFactor[];
  htmlContent?: string;
  loadTime?: number;
  pageSize?: number;
  screenshotUrl?: string;
}

// 分析结果按类别分组
export interface CategoryResults {
  [key: string]: {
    factors: SeoFactor[];
    score: number;
    maxScore: number;
    percentage: number;
  };
}

// 分析进度类型
export interface AnalysisProgress {
  status: 'idle' | 'loading' | 'analyzing' | 'completed' | 'error';
  message: string;
  progress: number; // 0-100
  currentTask?: string;
}

// 解析的页面数据类型
export interface ParsedPageData {
  title: string;
  metaDescription: string;
  metaKeywords: string[];
  h1Tags: string[];
  h2Tags: string[];
  h3Tags: string[];
  h4Tags: string[];
  h5Tags: string[];
  h6Tags: string[];
  paragraphs: number;
  wordCount: number;
  internalLinks: string[];
  externalLinks: string[];
  images: {
    total: number;
    withAlt: number;
    withoutAlt: number;
    altTexts: string[];
  };
  structuredData: any[];
  openGraphTags: any;
  twitterCards: any;
  hasHttps: boolean;
  url: string;
  robotsTxt?: string;
  sitemapXml?: string;
  loadTime?: number;
  redirectChain?: string[];
}